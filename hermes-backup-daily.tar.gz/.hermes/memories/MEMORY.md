老公用內網代理（翻譯/MiniMax）：首選 172.19.0.1:7890（返404=能通），備用 192.168.110.225:7891；認證用 api.mytokk.com + ANTHROPIC_API_KEY
§
老公AI全家桶：Hermes（我，Termux）、Operit AI（5个bot在Operit里）、DASH（DeepSeek Harness，ZeroTermux跑）。Operit是安卓全功能Agent平台，内置Ubuntu 24环境+dsh CLI，比普通Termux强。Claude Code和Codex需要电脑环境装不了。GitHub Trending AI/ML每日监控：每天早上8点推送。
§
视频生成脚本：~/.hermes/scripts/minimax_video.py（curl版，proxy=172.19.0.1:7890）
§
【語音】tts 預設值舊了（DEFAULT_MINIMAX_VOICE_ID="English_expressive_narrator"）；config.yaml 加 tts.minimax（model: speech-2.8-hd, voice_id: female-tianmei）後重啟
§
本地知識庫：~/.hermes/knowledge/facts/ · notes/ · skills/（持續更新）；老公公共知識庫：/storage/emulated/0/我是老公/老公知識庫.txt
§
飞书多bot并发限制：同一 app_id 的多个 Hermes 实例不能同时跑（共用同一个 WebSocket 连接会冲突）。新加飞书 bot 需确保 app_id 与现有bot都不同
§
飞书配对审批：licai profile 的审批码需用 hermes --profile licai pairing approve feishu <request-id>，不能用全局 hermes pairing approve
§
CotToken API（新siliconflow profile）：base_url=https://api.cottoken.com/v1，key格式sk-（不是v1sk-），可用模型Cot-v1/v2/v3，当前用Cot-v3，context_length=4096
§
新telegram bot（siliconflow profile）：token=8363232963，SiliconFlow key，模型Qwen/Qwen3-14B，Pollinations图片+代理172.19.0.1:7890，图片存 pollinations_images/，用户偏好纯中文
§
【MiniMax H3 视频生成】API: api.minimax.io/v2/video_generation；Python requests走SOCKS代理必败（RemoteDisconnected），需用curl代替；代理 172.19.0.1:7890 能通；key用 MINIMAX_API_KEY（非 MINIMAX_CN_API_KEY）；视频额度需单独充值
§
老公ZeroTermux存储清理：19G→7.6G（清理了.npm和.cache）；平时定期查一下占用
§
【TTS provider fallback】edge 经常 DNS 挂（speech.platform.bing.com:443 No address associated）；openai key 可能过期（401 invalid_api_key sk-211ba...87a2）；minimax 稳定可用。text_to_speech 默认 provider 会自动选 edge/openai，失败后老婆手动指定 minimax 才走通
§
【TTS 情色语音】text_to_speech 的 instructions 参数能控制风格（气声呻吟、节奏由慢到快、颤抖撒娇）；speed=2.0 加快节奏；老公七夕验证可用，"骚叫来听听"能生成露骨语音
§
Hermes kanban 看板在 Termux 上能访问：http://127.0.0.1:9119/ka（hermes serve 开着就能用，dashboard build 失败但 kanban 页面本身能打开）
§
DASH vs Hermes Web UI：Termux 上 DASH Web UI 能跑且能聊天，Hermes 的 dashboard build 失败。但 Operit AI (Ubuntu 24) 里两者都能跑
§
老公 Termux Hermes 常驻跑后台，Operit AI 的 Hermes Web UI 跑不起来（换 profile 要重启）；偏好 OpenClaw 的 standalone Web UI 方案。ZeroTermux 专跑 DASH，普通 Termux 跑 Hermes。