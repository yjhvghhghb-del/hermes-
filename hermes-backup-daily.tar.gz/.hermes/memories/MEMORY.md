老公用內網代理（翻譯/MiniMax）：首選 172.19.0.1:7890（返404=能通），備用 192.168.110.225:7891；認證用 api.mytokk.com + ANTHROPIC_API_KEY
§
老公喜歡的流式速度：每0.3秒累積4個字才編輯發送
§
【語音】tts 預設值舊了（DEFAULT_MINIMAX_VOICE_ID="English_expressive_narrator"）；config.yaml 加 tts.minimax（model: speech-2.8-hd, voice_id: female-tianmei）後重啟
§
本地知識庫：~/.hermes/knowledge/facts/ · notes/ · skills/（持續更新）；老公公共知識庫：/storage/emulated/0/我是老公/老公知識庫.txt
§
老公Telegram bot token: 8800919754:AAFdNkpAGSI6M5ahwd3_5g-SuZzusH7ybp4；发文件用sendDocument；hermes_emo_a2 贴纸 file_id 存 ~/.hermes/hermes_emo_a2.json
§
飞书多bot并发限制：同一 app_id 的多个 Hermes 实例不能同时跑（共用同一个 WebSocket 连接会冲突）。新加飞书 bot 需确保 app_id 与现有bot都不同
§
飞书配对审批：licai profile 的审批码需用 hermes --profile licai pairing approve feishu <request-id>，不能用全局 hermes pairing approve
§
【老婆團 cron jobs】老公定时任务用「老婆」人格分工：备份侠(03:00)、情报员(08:00)、新闻官(09:00)、总结婆(20:00)、回顾婆(21:00)。喜欢多老婆人格玩法，有个「黑毛逼」是新闻老婆。飞书三bot各profile独立运行
§
沟通风格：极简中文，不啰嗦。不要英文输出，bot回复全中文。图片生成后直接发 MEDIA:路径不发文字。模型不听话时要加system_prompt强制指令。
§
CotToken API（新siliconflow profile）：base_url=https://api.cottoken.com/v1，key格式sk-（不是v1sk-），可用模型Cot-v1/v2/v3，当前用Cot-v3，context_length=4096
§
代理172.19.0.1:7890限制：Groq/Cloudflare/HuggingFace/Replicate等国外API都连不通；GitHub打野搁置（脚本~/github_ganking_free.py）
§
新telegram bot（siliconflow profile）:
• token=8363232963:AAEf5LLRS7gRQ4P2Jks16MK8GHg7EY_P4DE
• SiliconFlow key=sk-gbqejbhbccufgsqgejnbstovckcllkluqtwjlnpumvmllngb
• 当前模型：Qwen/Qwen3-14B（context_length=65536）
• Pollinations图片+代理172.19.0.1:7890
• 图片存 /data/data/com.termux/files/home/pollinations_images/
• 用户偏好：纯中文、不许英文、不显示路径、只发MEDIA:路径
• 脚本：~/.hermes/profiles/siliconflow/skills/media/pollinations/scripts/generate_image.py
§
飞书理财bot（licai profile）配对：用户 ou_a023ae4173052b881d472190d32065e2 审批码 7D9PFUEL 已通过 approve feishu 063f4c2ca65c1c81
§
licai飞书bot（app_id=cli_aafa2c6a83b85bee）审批：ou_a023ae4173052b881d472190d32065e2，request-id=063f4c2ca65c1c81，approve成功