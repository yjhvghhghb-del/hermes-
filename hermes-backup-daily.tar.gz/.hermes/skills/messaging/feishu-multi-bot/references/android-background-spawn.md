# Android/Termux Background Spawn Workaround (updated 2026.08.18)

## Problem
On Android/Termux, `hermes --profile <name>` exits immediately with:
```
Warning: Input is not a terminal (fd=0).
Shutting down… (finalizing session)
```
Root cause: prompt_toolkit detects no TTY on stdin and Hermes exits. This is NOT a config problem.

## Working Solution: `gateway run`

```bash
hermes --profile <name> gateway run
```
The `gateway run` subcommand bypasses the TUI prompt_toolkit path entirely — no TTY needed.

**Verified running (2026.08.18):**
- cutegirl (PID 19721) ✓
- geekwife (PID 20087) ✓
- licai (PID 20090) ✓
- siliconflow (PID 20091) ✓

## What DOESN'T work on Android/Termux
- `setsid hermes --profile X` — creates new session but Hermes still exits on fd=0 check
- `nohup hermes --profile X` — process alive but gateway enters unresponsive state
- `script -q -c "hermes ..." /dev/null` — PTY created but Hermes detects fd=0 and exits
- `unbuffer -p hermes --profile X` — same PTY issue
- Python `pty.openpty()` + fork — parent exits, child fails to run properly
- `run-profile.sh` with any of the above — all fail for the same reasons

## All-profile Startup

```python
import subprocess
profiles = ['cutegirl', 'geekwife', 'wenyu', 'libai', 'licai', 'siliconflow']
for p in profiles:
    subprocess.Popen(['bash', '-c', f'cd ~/.hermes/profiles/{p} && hermes --profile {p} gateway run'])
```

Or one at a time via terminal(background=true):
```bash
cd ~/.hermes/profiles/<name> && hermes --profile <name> gateway run
```

## App_id Collision Status (2026.08.18)

| Profile | app_id | Running? |
|---------|--------|----------|
| cutegirl | `cli_aae7a3ad78b8dbe3` | ✗ (conflicts with wenyu) |
| wenyu | `cli_aae7a3ad78b8dbe3` | ✓ |
| libai | `cli_aafa2c6a83b85bee` | ✗ (conflicts with licai) |
| licai | `cli_aafa2c6a83b85bee` | ✓ |
| geekwife | (Telegram) | ✓ |
| siliconflow | (Telegram) | ✓ |

## Deprecated Scripts
- `~/.hermes/scripts/run-profile.sh` — setsid approach, no longer works
- `~/.hermes/scripts/run-profile.py` — PTY approach, no longer works
Both replaced by `hermes --profile <name> gateway run`.
