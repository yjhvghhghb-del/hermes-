---
name: telegram-bot-setup
description: 新建独立 Telegram Bot profile（独立性格+模型）
triggers:
  - 新建 Telegram Bot
  - 新建 Agent 接入电报
  - telegram bot 新 profile
---

# Telegram Bot 独立 Profile 接入

## 完整步骤

### 1. 创建 Profile
```bash
hermes profile create <profile_name>
```

### 2. 写 SOUL.md 性格设定
路径：`~/.hermes/profiles/<profile>/SOUL.md`

## config.yaml
```yaml
model:
  base_url: https://api.minimaxi.com/anthropic
  default: MiniMax-M2.7
  provider: minimax-cn

platforms:
  telegram:
    enabled: true
    dm_policy: open

streaming:
  enabled: true
  edit_interval: 0.3
  buffer_threshold: 4

_config_version: 33
```

> ⚠️ mytokk 不能直接接 Bot（指纹检测），用 MiniMax-M2.7；编程任务通过 `claude -p` 命令走 Opus-4-8

> ⚠️ **mytokk 不能直接接 Bot**：mytokk 有客户端指纹检测，非 Claude CLI 请求返回 http200 + 空 stream（EmptyStreamError）。Bot 对话直接用 `MiniMax-M2.7`，编程任务走 `claude -p` 命令调用 Opus-4-8。

### 4. 写 .env（必须！）
路径：`~/.hermes/profiles/<profile>/.env`
```
TELEGRAM_BOT_TOKEN=123456789:ABCDEFG...
ANTHROPIC_BASE_URL=https://api.mytokk.com
ANTHROPIC_AUTH_TOKEN=sk-xxxxxxxx
```

### 5. 启动
```bash
hermes -p <profile> gateway run
```

### 6. 配对
1. 用户 Telegram 搜 Bot 发消息 → 收到配对码
2. `hermes -p <profile> pairing approve telegram <CODE>`

## mytokk 配置要点

| 项 | 正确 | 错误 |
|---|---|---|
| Base URL | `https://api.mytokk.com` | 含 `/v1` 后缀 |
| 认证 | `ANTHROPIC_AUTH_TOKEN` | `ANTHROPIC_API_KEY` |

> ⚠️ **Bot 不能直接用 mytokk**：mytokk 客户端指纹检测导致 `custom` provider 返回 EmptyStreamError。Bot 只能走 MiniMax-M2.7，编程任务通过 `claude -p` 命令调用 Opus-4-8。

## 已知坑

### provider 必须是 custom
`anthropic-compatible` 不被识别 → "Unknown provider"。必须是 `custom`。

### 杀进程正确方式
- 看 PID：`hermes -p <profile> gateway status`
- 杀：`kill <PID>`
- 不要用 `hermes gateway stop`（操作 default profile）
