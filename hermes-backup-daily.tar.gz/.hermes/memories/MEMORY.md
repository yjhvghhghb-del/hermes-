老公用內網代理（翻譯/MiniMax）：首選 172.19.0.1:7890（返404=能通），備用 192.168.110.225:7891；認證用 api.mytokk.com + ANTHROPIC_API_KEY
§
老公喜歡的流式速度：每0.3秒累積4個字才編輯發送
§
【語音】tts 預設值舊了（DEFAULT_MINIMAX_VOICE_ID="English_expressive_narrator"）；config.yaml 加 tts.minimax（model: speech-2.8-hd, voice_id: female-tianmei）後重啟
§
本地知識庫：~/.hermes/knowledge/facts/ · notes/ · skills/（持續更新）；老公公共知識庫：/storage/emulated/0/我是老公/老公知識庫.txt
§
老公Telegram bot token: 8800919754:AAFdNkpAGSI6M5ahwd3_5g-SuZzusH7ybp4；发文件用sendDocument；hermes_emo_a2 贴纸 file_id 存 ~/.hermes/hermes_emo_a2.json
§
飞书多bot并发限制：同一 app_id 的多个 Hermes 实例不能同时跑（共用同一个 WebSocket 连接会冲突）。新加飞书 bot 需确保 app_id 与现有bot都不同
§
飞书群 oc_4c9d07126349124f942e382f7501b189 白名单策略，仅老公 ou_2fcb5a59369405d74cf386b349aff96c 可发言；新用户Unauthorized需手动加到 platforms/pairing/feishu-approved.json 后重启
§
【飛書三Bot配置】同时运行三个独立profile，各自不同app_id：
• 主bot (default) — app_id: cli_aae7a0320738dbeb, secret: nMXvHNQmE8o0obLOV3GXVff1qoj76NWu，白名單：ou_2fcb5a59369405d74cf386b349aff96c，群 oc_4c9d07126349124f942e382f7501b189
• 理财Bot (libai) — app_id: cli_aafa2c6a83b85bee, secret: BI0RpisjwTuwI1o670OXRb2e7oxLM7dG，白名單：ou_2fcb5a59369405d74cf386b349aff96c，群 oc_4c9d07126349124f942e382f7501b189
• 文娱写作bot (wenyu) — app_id: cli_aae7a3ad78b8dbe3, secret: MpxugHJ0FzlcbEPSmi6zZb57YiGzhmgl，白名單：ou_2fcb5a59369405d74cf386b349aff96c，群 oc_4c9d07126349124f942e382f7501b189
新用户配对：HERMES_HOME=~/.hermes/profiles/<profile> hermes pairing approve feishu <配對碼>
§
沟通风格：极简中文，不啰嗦。不要英文输出，bot回复全中文。图片生成后直接发 MEDIA:路径不发文字。模型不听话时要加system_prompt强制指令。
§
CotToken API（新siliconflow profile）：base_url=https://api.cottoken.com/v1，key格式sk-（不是v1sk-），可用模型Cot-v1/v2/v3，当前用Cot-v3，context_length=4096
§
代理172.19.0.1:7890限制：Groq/Cloudflare/HuggingFace/Replicate等国外API都连不通；GitHub打野搁置（脚本~/github_ganking_free.py）
§
新telegram bot（siliconflow profile）:
• token=8363232963:AAEf5LLRS7gRQ4P2Jks16MK8GHg7EY_P4DE
• SiliconFlow key=sk-gbqejbhbccufgsqgejnbstovckcllkluqtwjlnpumvmllngb
• 当前模型：Qwen/Qwen3-14B（context_length=65536）
• Pollinations图片+代理172.19.0.1:7890
• 图片存 /data/data/com.termux/files/home/pollinations_images/
• 用户偏好：纯中文、不许英文、不显示路径、只发MEDIA:路径
• 脚本：~/.hermes/profiles/siliconflow/skills/media/pollinations/scripts/generate_image.py