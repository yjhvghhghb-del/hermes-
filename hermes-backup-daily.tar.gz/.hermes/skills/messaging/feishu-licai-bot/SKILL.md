---
name: feishu-licai-bot
description: 理财Bot (licai/libai profile) 启动、排错、SSL断开修复、群里无响应诊断。
tags: [feishu, licai, libai, 理财]
---

# 飞书理财Bot

## 基本信息
- **Profile**: `~/.hermes/profiles/licai/`
- **App ID**: `cli_aafa2c6a83b85bee`
- **App Secret**: `BI0RpisjwTuwI1o670OXRb2e7oxLM7dG`
- **Gateway**: `hermes gateway run --profile licai`
- **日志**: `~/.hermes/profiles/licai/logs/gateway.log`

## 启动/重启
```bash
# 查看当前 gateway 状态
hermes gateway list

# 查看 licai 是否在跑
ps aux | grep "hermes gateway.*licai" | grep -v grep

# 启动（licai 是独立 profile，必须用 --profile 指定）
hermes gateway run --profile licai

# 重启（先杀后启）
kill <PID> && hermes gateway run --profile licai
```

## 配对审批（新用户首次使用）
licai 的飞书bot 审批码需要用 `--profile` 指定，否则会找不到：
```bash
# 查看待审批（licai profile）
hermes --profile licai pairing list

# 审批（用 request-id，不是配对码）
hermes --profile licai pairing approve feishu <request-id>
```

审批后，还需要在 config.yaml 两处加入用户的 open_id 才能在群里发言（见下一节）。

## 群白名单配置（新用户加入群聊）
licai 的群白名单策略是 `allowlist`，每个新用户需要在 config.yaml 两处都加上 open_id：

```yaml
platforms:
  feishu:
    extra:
      allowed_group_users:
      - ou_2fcb5a59369405d74cf386b349aff96c   # 老公
      - ou_a023ae4173052b881d472190d32065e2   # 新用户
      group_rules:
        oc_4c9d07126349124f942e382f7501b189:
          allowlist:
          - ou_2fcb5a59369405d74cf386b349aff96c
          - ou_a023ae4173052b881d472190d32065e2
          policy: allowlist
```

加完后重启 licai gateway：
```bash
kill <PID> && hermes gateway run --profile licai
```

## 快速诊断 checklist
```bash
# 1. 注意：hermes gateway list 对 profile-specific gateway 有误报，
#    即使 licai 在跑也可能显示 ✗ licai — 不要信任这个！
ps aux | grep "hermes gateway.*licai" | grep -v grep
# 有两行输出（bash wrapper + python进程）= 正常运行

# 2. 确认飞书是否连上
grep "feishu connected" ~/.hermes/profiles/licai/logs/gateway.log

# 3. 飞书是否连上
grep "feishu connected" ~/.hermes/profiles/licai/logs/gateway.log

# 4. 是否有收到消息
grep "inbound message" ~/.hermes/profiles/licai/logs/gateway.log

# 5. 是否有新用户待审批
hermes --profile licai pairing list
```

## 启动检查
```bash
# 确认飞书连接成功
grep "feishu connected" ~/.hermes/profiles/licai/logs/gateway.log

# 确认收到消息（licai 收到消息才会有 inbound 日志）
grep "inbound message" ~/.hermes/profiles/licai/logs/gateway.log
```

## 已知问题

### SSL EOFError 导致 WebSocket 断开
`errors.log` 大量 `Lark: receive message loop exit` + `SSLEOFError`。Bot 进程可能还活着但群消息停了。
```bash
tail -10 ~/.hermes/profiles/libai/logs/errors.log
grep "Inbound group" ~/.hermes/profiles/libai/logs/gateway.log
```

### 群里 @ 不响应——两种可能
**可能1: `require_mention: true`（默认）导致静默忽略**
飞书 adapter 默认 `require_mention: true`，即使 `default_group_policy: open` 也只响应被 @ 的消息。在 config 里加：
```yaml
platforms:
  feishu:
    extra:
      require_mention: false  # 不需要 @ 就能回复群消息
      default_group_policy: open
```

**可能2: 飞书平台限制——同群多 bot @事件只推给最早加入的**
当两个 bot（理财bot + 嗨妹小老婆）在同一个群时，**@mention 事件只推给最早加入群的 bot**，后加的 bot 永远收不到任何 @事件。这是飞书平台级限制，非配置问题。
诊断：
```bash
# 看 libai 是否有收到群消息（不应该有，因为被嗨妹抢了）
grep "Inbound group" ~/.hermes/profiles/libai/logs/gateway.log

# 看嗨妹小老婆的（应该有）
grep "Inbound group" ~/.hermes/logs/gateway.log
```
如果 libai 的 log 里群消息为空 → 确认是这个平台限制。

**解决方案**：把理财bot 和 嗨妹小老婆 放在不同群；或者接受只有嗨妹小老婆能响应 @，理财bot 只能 DM。

### app_id 冲突
此 bot 的 app_id (`cli_aafa2c6a83b85bee`) 与 libai profile 共用，**licai 和 libai 不能同时跑**，只能选一个。检查：
```bash
hermes gateway list | grep -E 'licai|libai'
```
如果要跑 libai，先停 licai，反之亦然。
