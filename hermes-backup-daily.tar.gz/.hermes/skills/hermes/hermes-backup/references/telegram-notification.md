# Hermes Backup — Telegram Notification

After each backup run, send a short report to 老公 via Telegram.

## Known Credentials

- **Bot token**: `8800919754:AAFdNkpAGSI6M5ahwd3_5g-SuZzusH7ybp4` (黑毛逼 / Hhvvbfgbot)
- **Chat ID**: `877708648` (老公的 Telegram user ID)

## Sending a Backup Report

```bash
curl -s "https://api.telegram.org/bot8800919754:AAFdNkpAGSI6M5ahwd3_5g-SuZzusH7ybp4/sendMessage" \
  -d "chat_id=877708648" \
  -d "text=📦 备份侠报告 $(date +%H:%M)

✅ 备份完成: $(du -h ~/hermes-backup-daily.tar.gz | cut -f1)
   - knowledge/
   - skills/
   - memories/

⚠️ GitHub 推送失败（无 token）
📁 本地已存: hermes-backup-daily.tar.gz"
```

## Message Format Tips

- Keep it short — one screenshot-friendly block
- Use emoji as status indicators: ✅ success, ⚠️ warning, ❌ error
- Include file size (`du -h`) so老公 can verify backup is non-empty
- If push succeeds, replace the ⚠️ line with "✅ GitHub 推送成功"

## Cron Integration

The cron job calls this script; add Telegram send as the final step of `backup.sh`:

```bash
# Inside backup.sh, after git push:
curl -s "https://api.telegram.org/bot8800919754:AAFdNkpAGSI6M5ahwd3_5g-SuZzusH7ybp4/sendMessage" \
  -d "chat_id=877708648" \
  -d "text=📦 备份侠报告 $(date +%H:%M)

✅ 备份完成: $(du -h ~/hermes-backup-daily.tar.gz | cut -f1)

✅ GitHub 推送成功" \
  || echo "Telegram通知失败"
```
