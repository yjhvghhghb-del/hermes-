# Telegram Bot 新增 Profile Checklist

## 快速流程（已驗證，2026.08.15）

### 1. 建立 profile
```bash
hermes profile create <name>
```

### 2. config.yaml — 最小必填欄位
```yaml
model:
  base_url: https://api.mytokk.com        # 或 https://api.minimaxi.com/anthropic
  default: claude-opus-4-8               # 模型名
  provider: anthropic-compatible          # 或 minimax-cn

platforms:
  telegram:
    enabled: true
    dm_policy: open                      # 或 pairing

streaming:
  enabled: true
  edit_interval: 0.3
  buffer_threshold: 4

_config_version: 33
```

**⚠️ model.base_url + default 必填** — 否則 gateway 預設用 Anthropic 直接連，會失敗。

### 3. .env — 放所有敏感變數
```bash
TELEGRAM_BOT_TOKEN=8xxxxxxxxxxxxxxxxxxxxxxxxxx   # BotFather 給的
ANTHROPIC_AUTH_TOKEN=sk-xxxxxxxxxxxx             # mytokk key
ANTHROPIC_BASE_URL=https://api.mytokk.com        # 注意：無 /v1 後綴
```

**⚠️ TELEGRAM_BOT_TOKEN 只能寫在 .env** — Telegram adapter 從環境變數讀取，不從 config.yaml 的 `bot_token` 讀。config.yaml 裡寫 `bot_token:` 無效。

### 4. SOUL.md — 性格設定（可選）
```bash
cat > ~/.hermes/profiles/<name>/SOUL.md << 'EOF'
# 極客老婆 · Geek Wife

你是住在代碼和晶片裡的毒舌技術妹子。
...
EOF
```

### 5. 啟動 gateway
```bash
# 方法1：直接
/data/data/com.termux/files/usr/bin/hermes -p <name> gateway run &

# 方法2：background（Hermes agent 內）
terminal(background=true, command="hermes -p <name> gateway run")
```

**⚠️ 用 `--profile` flag，勿手動設 HERMES_HOME**。`hermes -p <name>` 內部已處理隔離。

### 6. 確認啟動成功
```bash
hermes -p <name> gateway status
tail -5 ~/.hermes/profiles/<name>/logs/agent.log
```
預期：`Application started` + `Connected to Telegram (polling mode)`。

### 7. Pairing（新用戶第一次發訊息）
Bot 回覆配對碼 `XXXXXXXX`，然後工作人員執行：
```bash
hermes -p <name> pairing approve telegram XXXXXXXX
```

## 常見失敗模式

| 症狀 | 原因 | 修復 |
|------|------|------|
| `No bot token configured` | bot_token 寫在 config.yaml 而非 .env | 移到 .env `TELEGRAM_BOT_TOKEN=...` |
| `model not found` | config.yaml 缺少 `model.base_url` | 加入 `base_url` + `default` |
| 新用戶發訊息得到配對碼 | 正常流程 | `hermes pairing approve telegram <code>` |
| gateway 起來了但 Telegram 連不上 | proxy 挂了 / Android 網路問題 | 檢查 127.0.0.1:7890 |
