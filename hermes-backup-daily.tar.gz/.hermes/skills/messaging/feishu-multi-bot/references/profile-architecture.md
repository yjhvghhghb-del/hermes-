# Profile Architecture (as of 2026.08.11)

## Active Profiles

| Profile | Platform | app_id | Status | Notes |
|---------|----------|--------|--------|-------|
| `default` | QQ + 飞书 + 电报 | `cli_aae7a0320738dbeb` (飞书) | ✅ running | 主bot，QQ App ID 1905311551 |
| `siliconflow` | 电报 | — | ✅ running | bot token: 8363232963:AAEf5LLRS7gRQ4P2Jks16MK8GHg7EY_P4DE |
| `licai` | 飞书 | `cli_aafa2c6a83b85bee` | ✅ running | 理财Bot |
| `wenyu` | 飞书 | `cli_aae7a3ad78b8dbe3` | ✅ running | 文娱写作bot |
| `libai` | 飞书 | `cli_aafa2c6a83b85bee` | ❌ cannot run | 和licai同app_id，只能选一个 |
| `cutegirl` | 飞书 | `cli_aae7a3ad78b8dbe3` | ❌ cannot run | 和wenyu同app_id，只能选一个 |

## app_id Collision Groups

```
Group A: cli_aae7a0320738dbeb → default
Group B: cli_aafa2c6a83b85bee → libai / licai (二选一)
Group C: cli_aae7a3ad78b8dbe3 → cutegirl / wenyu (二选一)
```

最多同时跑3个飞书bot（各属不同group）+ 电报bot + QQ（default自带）。

## Startup Commands

```bash
# All running bots as of 2026.08.11:
hermes gateway run                                      # default (QQ/飞书/电报)
hermes gateway run --profile siliconflow                # 电报 bot
hermes gateway run --profile licai                      # 飞书理财
hermes gateway run --profile wenyu                      # 飞书文娱
```

## Log Locations

```
default:       ~/.hermes/logs/gateway.log
siliconflow:   ~/.hermes/profiles/siliconflow/logs/gateway.log
licai:         ~/.hermes/profiles/licai/logs/gateway.log
wenyu:         ~/.hermes/profiles/wenyu/logs/gateway.log
```

## Diagnostic Commands

```bash
# Quick status
hermes gateway list

# All running gateway processes
ps aux | grep 'hermes gateway' | grep -v grep

# Check specific profile logs
tail -30 ~/.hermes/profiles/licai/logs/gateway.log

# Verify no app_id collisions
for p in cutegirl libai licai wenyu default; do
  echo -n "$p: "
  grep "app_id" ~/.hermes/profiles/$p/config.yaml 2>/dev/null || grep "app_id" ~/.hermes/config.yaml 2>/dev/null
done
```
